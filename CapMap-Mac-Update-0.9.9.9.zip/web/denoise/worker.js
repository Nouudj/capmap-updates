/* "Stimme verbessern": DeepFilterNet3 (Schröter et al., MIT/Apache-2.0), streaming ONNX export (torchDF), on this device only.
   Input: mono 48 kHz Float32Array. The model takes 10 ms (480 samples) at a time and hands its 12 states on to the next step. */
import * as ort from './ort.min.mjs';
const ERB0 = new Float32Array([-60.0, -60.967743, -61.935482, -62.903225, -63.870968, -64.838707, -65.80645, -66.774193, -67.741936, -68.709679, -69.677422, -70.645164, -71.6129, -72.580643, -73.548386, -74.516129, -75.483871, -76.451614, -77.419357, -78.3871, -79.354836, -80.322578, -81.290321, -82.258064, -83.225807, -84.19355, -85.161293, -86.129036, -87.096771, -88.064514, -89.032257, -90.0]), DF0 = new Float32Array([0.001, 0.00099053, 0.00098105, 0.00097158, 0.00096211, 0.00095263, 0.00094316, 0.00093368, 0.00092421, 0.00091474, 0.00090526, 0.00089579, 0.00088632, 0.00087684, 0.00086737, 0.00085789, 0.00084842, 0.00083895, 0.00082947, 0.00082, 0.00081053, 0.00080105, 0.00079158, 0.00078211, 0.00077263, 0.00076316, 0.00075368, 0.00074421, 0.00073474, 0.00072526, 0.00071579, 0.00070632, 0.00069684, 0.00068737, 0.00067789, 0.00066842, 0.00065895, 0.00064947, 0.00064, 0.00063053, 0.00062105, 0.00061158, 0.00060211, 0.00059263, 0.00058316, 0.00057368, 0.00056421, 0.00055474, 0.00054526, 0.00053579, 0.00052632, 0.00051684, 0.00050737, 0.00049789, 0.00048842, 0.00047895, 0.00046947, 0.00046, 0.00045053, 0.00044105, 0.00043158, 0.00042211, 0.00041263, 0.00040316, 0.00039368, 0.00038421, 0.00037474, 0.00036526, 0.00035579, 0.00034632, 0.00033684, 0.00032737, 0.00031789, 0.00030842, 0.00029895, 0.00028947, 0.00028, 0.00027053, 0.00026105, 0.00025158, 0.00024211, 0.00023263, 0.00022316, 0.00021368, 0.00020421, 0.00019474, 0.00018526, 0.00017579, 0.00016632, 0.00015684, 0.00014737, 0.00013789, 0.00012842, 0.00011895, 0.00010947, 0.0001]);
const SHAPES = {erb_norm_state:[32], band_unit_norm_state:[1, 96, 1], analysis_mem:[480], synthesis_mem:[480], rolling_erb_buf:[1, 1, 3, 32], rolling_feat_spec_buf:[1, 2, 3, 96],
  rolling_c0_buf:[1, 64, 5, 96], rolling_spec_buf_x:[5, 481, 2], rolling_spec_buf_y:[7, 481, 2], enc_hidden:[1, 1, 256], erb_dec_hidden:[2, 1, 256], df_dec_hidden:[2, 1, 256]};
const HOP = 480, FFT = 960;
let sess = null;
async function joinParts(base, files){ const parts = await Promise.all(files.map(f => fetch(base + f).then(r => { if (!r.ok) throw new Error('fehlt: ' + f); return r.arrayBuffer(); }))); const n = parts.reduce((a, b) => a + b.byteLength, 0), out = new Uint8Array(n); let o = 0; for (const p of parts) { out.set(new Uint8Array(p), o); o += p.byteLength; } return out.buffer; }
const ORT_CDN = 'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.22.0-dev.20250409-89f8206ba4/dist/';
async function load(base){
  if (sess) return sess;
  // the runtime is the one the speech recognition already ships (asr/ort0+ort1); without it (web version) it comes from jsDelivr
  const asr = new URL('../asr/', base).href;
  ort.env.wasm.numThreads = 1; ort.env.wasm.proxy = false;
  let local = false; try { const r = await fetch(asr + 'ort0.wasm', {method:'HEAD'}); local = r.ok; } catch (err) {}
  if (local) { ort.env.wasm.wasmPaths = asr; ort.env.wasm.wasmBinary = await joinParts(asr, ['ort0.wasm', 'ort1.wasm']); } else ort.env.wasm.wasmPaths = ORT_CDN;
  const r = await fetch(new URL('dfn3.wasm', base).href); if (!r.ok) throw new Error('Modell fehlt');
  sess = await ort.InferenceSession.create(await r.arrayBuffer(), {executionProviders:['wasm'], graphOptimizationLevel:'all'});
  return sess;
}
function initStates(){ const s = {}; for (const [k, sh] of Object.entries(SHAPES)) { const n = sh.reduce((a, b) => a * b, 1), d = k === 'erb_norm_state' ? ERB0.slice() : k === 'band_unit_norm_state' ? DF0.slice() : new Float32Array(n); s[k] = new ort.Tensor('float32', d, sh); } return s; }
self.onmessage = async e => {
  const {id, pcm, base, strength} = e.data;
  try {
    let S; try { S = await load(base || self.location.href); } catch (err) { throw new Error('LOAD: ' + (err && err.message || err)); }
    const len = pcm.length, pad = (HOP - len % HOP) % HOP, x = new Float32Array(len + pad + FFT); x.set(pcm);
    const N = x.length / HOP, y = new Float32Array(x.length); let st = initStates(), t0 = performance.now();
    for (let i = 0; i < N; i++) {
      const feeds = {input_frame:new ort.Tensor('float32', x.subarray(i * HOP, (i + 1) * HOP).slice(), [HOP]), ...st};
      const r = await S.run(feeds);
      y.set(r.enhanced_audio_frame.data, i * HOP);
      const ns = {}; for (const k of Object.keys(SHAPES)) ns[k] = r['new_' + k]; st = ns;
      if (i % 100 === 0) self.postMessage({id, progress:i / N, rate:(i * HOP / 48000) / ((performance.now() - t0) / 1000)});
    }
    self.postMessage({id, progress:1});
    const d = FFT - HOP, out = y.slice(d, d + len);
    // strength < 1 mixes a little of the original back in (sounds more natural on light noise)
    const k = strength == null ? 1 : Math.max(0, Math.min(1, strength)); if (k < 1) for (let i = 0; i < len; i++) out[i] = out[i] * k + pcm[i] * (1 - k);
    self.postMessage({id, done:true, pcm:out, secs:(performance.now() - t0) / 1000}, [out.buffer]);
  } catch (err) { self.postMessage({id, error:String(err && err.message || err)}); }
};

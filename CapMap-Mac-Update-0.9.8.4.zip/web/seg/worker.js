// Person cut-out worker for CapMap: MODNet portrait matting (Apache-2.0) with the ONNX runtime from transformers.js.
// The model is published in three parts (the host caps single files); where they are missing it comes once from the npm CDN.
const BASE = new URL('./', self.location.href).href, ASR = new URL('../asr/', self.location.href).href;
const PARTS = ['m0.wasm', 'm1.wasm', 'm2.wasm'], SIZE = 25888640;
const CDN = ['https://cdn.jsdelivr.net/npm/@rmbg/model-modnet@0.0.1/', 'https://unpkg.com/@rmbg/model-modnet@0.0.1/'], CDN_PARTS = ['modnet-1.onnx', 'modnet-2.onnx', 'modnet-3.onnx'];
const WASM = {files:['ort0.wasm', 'ort1.wasm']};
let loaded = 0, lastReport = 0;
const report = () => { const n = Date.now(); if (n - lastReport > 150) { lastReport = n; postMessage({type:'progress', loaded, total:SIZE}); } };
async function readAll(url, count){
  const r = await realFetch(url); if (!r.ok) throw new Error('Datei fehlt: ' + url.split('/').pop());
  if (!r.body || !r.body.getReader) { const b = new Uint8Array(await r.arrayBuffer()); if (count) { loaded += b.length; report(); } return b; }
  const rd = r.body.getReader(), ch = []; let n = 0;
  for (;;) { const {done, value} = await rd.read(); if (done) break; ch.push(value); n += value.length; if (count) { loaded += value.length; report(); } }
  const out = new Uint8Array(n); let o = 0; for (const c of ch) { out.set(c, o); o += c.length; } return out;
}
async function join(urls, count){ const b = []; for (const u of urls) b.push(await readAll(u, count)); const out = new Uint8Array(b.reduce((a, x) => a + x.length, 0)); let o = 0; for (const x of b) { out.set(x, o); o += x.length; } return out; }
async function modelBytes(){
  try { return await join(PARTS.map(f => BASE + f), true); } catch (err) { loaded = 0; }
  const CACHE = 'capmap-modnet-v1', KEY = 'https://capmap.invalid/modnet.onnx';
  try { const c = await caches.open(CACHE), r = await c.match(KEY); if (r) return new Uint8Array(await r.arrayBuffer()); } catch (err) {}
  let last = null;
  for (const c of CDN) {
    try { loaded = 0; const b = await join(CDN_PARTS.map(f => c + f), true); try { await (await caches.open(CACHE)).put(KEY, new Response(b)); } catch (err) {} return b; }
    catch (err) { last = err; }
  }
  throw last || new Error('Modell nicht erreichbar');
}
const MODEL_DIR = BASE + 'models/Xenova/modnet/';
const realFetch = self.fetch.bind(self); let modelBuf = null;
self.fetch = async (input, init) => {
  const url = String(typeof input === 'string' ? input : (input && input.url) || input).split('?')[0];
  if (url.startsWith(MODEL_DIR)) {
    const rel = url.slice(MODEL_DIR.length);
    if (rel === 'onnx/model.onnx') { if (!modelBuf) modelBuf = await modelBytes(); return new Response(modelBuf, {status:200, headers:{'Content-Type':'application/octet-stream', 'Content-Length':String(modelBuf.length)}}); }
    if (rel === 'config.json') return new Response('{"model_type":"modnet"}', {status:200, headers:{'Content-Type':'application/json'}});
    return new Response('not found', {status:404});
  }
  return realFetch(input, init);
};
let tf = null, model = null, device = 'wasm', loading = null;
async function init(){
  if (model) return;
  if (loading) return loading;
  loading = (async () => {
    postMessage({type:'status', text:'Präzise Freistellung wird geladen'});
    tf = await import(ASR + 'transformers.min.js');
    const env = tf.env; env.allowRemoteModels = false; env.allowLocalModels = true; env.localModelPath = BASE + 'models/'; env.useBrowserCache = false;
    const wasm = env.backends.onnx.wasm; wasm.numThreads = self.crossOriginIsolated ? Math.max(1, Math.min(4, (navigator.hardwareConcurrency || 2) - 1)) : 1; wasm.proxy = false;
    let local = false;
    try { const r = await realFetch(ASR + WASM.files[0]); local = r.ok; if (r.body && r.body.cancel) r.body.cancel(); } catch (err) {}
    if (local && !wasm.wasmBinary) { wasm.wasmPaths = ASR; wasm.wasmBinary = (await join(WASM.files.map(f => ASR + f), false)).buffer; }
    let m = null;
    let gpu = false; try { gpu = !!(self.navigator && navigator.gpu && await navigator.gpu.requestAdapter()); } catch (err) {}
    if (gpu) { try { m = await tf.AutoModel.from_pretrained('Xenova/modnet', {dtype:'fp32', device:'webgpu'}); device = 'webgpu'; } catch (err) { m = null; } }
    if (!m) { m = await tf.AutoModel.from_pretrained('Xenova/modnet', {dtype:'fp32', device:'wasm'}); device = 'wasm'; }
    model = m; modelBuf = null; postMessage({type:'progress', loaded:SIZE, total:SIZE}); postMessage({type:'ready', device});
  })();
  try { await loading; } catch (err) { loading = null; throw err; }
}
self.onmessage = async e => {
  const m = e.data;
  if (m.type === 'init') { try { await init(); } catch (err) { postMessage({type:'error', message:String(err && err.message || err)}); } return; }
  if (m.type !== 'seg') return;
  try {
    await init();
    const {w, h} = m, px = new Uint8ClampedArray(m.data), n = w * h, x = new Float32Array(3 * n);
    for (let i = 0; i < n; i++) { const j = i * 4; x[i] = px[j] / 127.5 - 1; x[n + i] = px[j + 1] / 127.5 - 1; x[2 * n + i] = px[j + 2] / 127.5 - 1; }
    let out;
    try { out = await model({input:new tf.Tensor('float32', x, [1, 3, h, w])}); }
    catch (err) {
      if (device !== 'webgpu') throw err;
      // the graphics card failed: continue on the processor
      model = await tf.AutoModel.from_pretrained('Xenova/modnet', {dtype:'fp32', device:'wasm'}); device = 'wasm'; postMessage({type:'ready', device});
      out = await model({input:new tf.Tensor('float32', x, [1, 3, h, w])});
    }
    const a = (out.output || Object.values(out)[0]).data, mk = new Uint8ClampedArray(n * 4);
    for (let i = 0; i < n; i++) { const j = i * 4; mk[j] = mk[j + 1] = mk[j + 2] = 255; mk[j + 3] = a[i] * 255; }
    postMessage({type:'mask', id:m.id, w, h, data:mk.buffer}, [mk.buffer]);
  } catch (err) { postMessage({type:'error', id:m.id, message:String(err && err.message || err)}); }
};

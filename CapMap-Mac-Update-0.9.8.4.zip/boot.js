'use strict';
// Starts the newest CapMap code: the one shipped inside the app, or a newer one the updater put together
// in the user folder (small updates). The installed app itself is never touched by these updates.
const { app } = require('electron');
const path = require('path');
const fs = require('fs');

function cmpVer(a, b) {
  const p = v => String(v || '').replace(/^v/i, '').split(/[.\-+]/).map(x => (isFinite(+x) ? +x : 0));
  const A = p(a), B = p(b);
  for (let i = 0; i < Math.max(A.length, B.length, 3); i++) { const d = (A[i] || 0) - (B[i] || 0); if (d) return d > 0 ? 1 : -1; }
  return 0;
}
const readVer = d => { try { return JSON.parse(fs.readFileSync(path.join(d, 'package.json'), 'utf8')).version; } catch (e) { return null; } };

process.env.CAPMAP_BASE_DIR = __dirname;
let dir = __dirname, best = readVer(__dirname);
// Mac and Windows: small updates are put together in the user folder; the newest complete one wins
{
  const root = path.join(app.getPath('userData'), 'app-updates');
  try {
    for (const d of fs.readdirSync(root)) {
      const full = path.join(root, d), v = readVer(full);
      if (v && fs.existsSync(path.join(full, 'main.js')) && cmpVer(v, best) > 0) { best = v; dir = full; }
    }
  } catch (e) {}
}
process.env.CAPMAP_CODE_DIR = dir;
require(path.join(dir, 'main.js'));
